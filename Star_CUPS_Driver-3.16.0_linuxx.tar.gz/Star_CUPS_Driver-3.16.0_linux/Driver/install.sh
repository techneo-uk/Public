#!/bin/sh

#64bit
rpm -ivh Star_CUPS_Driver-3.16.0-1.x86_64.rpm
